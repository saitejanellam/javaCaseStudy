package com.ecom.service;

import java.util.List;
import java.util.Map;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;

public interface IOrderService {
	boolean placeOrder(Customer customer, List<Map<Product, Integer>> productsAndQuantities, String shippingAddress);

	List<Map<Product, Integer>> getOrdersByCustomer(int customerId);
}
