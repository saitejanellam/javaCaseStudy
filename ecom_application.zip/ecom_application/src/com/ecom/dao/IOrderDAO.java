package com.ecom.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;
import com.ecom.exception.OrderNotFoundException;
import com.ecom.exception.ProductNotFoundException;

public interface IOrderDAO {

    boolean placeOrder(Customer customer, List<Map<Product, Integer>> productsAndQuantities, String shippingAddress)
            throws ClassNotFoundException, SQLException;

    List<Map<Product, Integer>> getOrdersByCustomer(int customerId)
            throws ClassNotFoundException, SQLException, OrderNotFoundException, ProductNotFoundException;
}
