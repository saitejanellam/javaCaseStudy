package com.ecom.dao;

import java.sql.SQLException;
import java.util.List;

import com.ecom.entity.Customer;
import com.ecom.exception.CustomerNotFoundException;

public interface ICustomerDAO {
	public boolean createCustomer(Customer customer) throws ClassNotFoundException, SQLException;

	public boolean deleteCustomer(int customerId)
			throws ClassNotFoundException, SQLException, CustomerNotFoundException;

	public Customer viewCustomer(int customerId) throws ClassNotFoundException, SQLException, CustomerNotFoundException;

	public List<Customer> viewCustomers() throws ClassNotFoundException, SQLException, CustomerNotFoundException;
}
