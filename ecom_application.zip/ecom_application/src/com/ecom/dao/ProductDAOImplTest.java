package com.ecom.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Product;
import com.ecom.exception.ProductNotFoundException;

public class ProductDAOImplTest {

	private IProductDAO productDAO;

	@Before
	public void setUp() throws Exception {
		productDAO = new ProductDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		productDAO = null;
	}

	@Test
	public final void testCreateProduct() {
		boolean result = false;
		Product product = new Product("AC", 6000.00, "Worlds no.1 AC", 5);
		try {
			result = productDAO.createProduct(product);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		assertTrue("Product creation should be successful", result);
	}

	@Test
	public final void testDeleteProduct() {
		boolean result = false;
		int productId = 8;
		try {
			result = productDAO.deleteProduct(productId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ProductNotFoundException pnfe) {
			System.out.println(pnfe.getMessage());
		}

		assertTrue("Product deletion should be successful", result);
	}

	@Test
	public final void testViewProduct() {
		Product product = null;
		int productId = 3;
		try {
			product = productDAO.viewProduct(productId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ProductNotFoundException pnfe) {
			System.out.println(pnfe.getMessage());
		}

		assertTrue("Product should not be null", product != null);
	}

	@Test
	public final void testViewProducts() {
		List<Product> productList = null;

		try {
			productList = productDAO.viewProducts();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ProductNotFoundException pnfe) {
			System.out.println(pnfe.getMessage());
		}
		assertTrue("Product list should not be null", productList != null);

	}

}
