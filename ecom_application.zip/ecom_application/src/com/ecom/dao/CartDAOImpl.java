package com.ecom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;
import com.ecom.util.DBUtil;

public class CartDAOImpl implements ICartDAO {

	@Override
	public boolean addToCart(Customer customer, Product product, int quantity)
			throws ClassNotFoundException, SQLException {
		try (Connection connection = DBUtil.createConnection()) {
			if (isProductInCart(connection, customer, product)) {
				return false;
			}

			String sql = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, customer.getCustomerId());
				statement.setInt(2, product.getProductId());
				statement.setInt(3, quantity);

				int rowsInserted = statement.executeUpdate();
				return rowsInserted > 0;
			}
		}
	}

	@Override
	public boolean removeFromCart(Customer customer, Product product) throws ClassNotFoundException, SQLException {
		try (Connection connection = DBUtil.createConnection()) {
			if (!isProductInCart(connection, customer, product)) {
				return false; // Product is not in the cart
			}

			String sql = "DELETE FROM cart WHERE customer_id = ? AND product_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, customer.getCustomerId());
				statement.setInt(2, product.getProductId());

				int rowsDeleted = statement.executeUpdate();
				return rowsDeleted > 0;
			}
		}
	}

	@Override
	public List<Product> getAllFromCart(Customer customer) throws ClassNotFoundException, SQLException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "SELECT p.* FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.customer_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, customer.getCustomerId());

				try (ResultSet resultSet = statement.executeQuery()) {
					List<Product> productList = new ArrayList<>();
					while (resultSet.next()) {
						Product product = new Product();
						product.setProductId(resultSet.getInt("product_id"));
						product.setName(resultSet.getString("name"));
						product.setPrice(resultSet.getDouble("price"));
						product.setDescription(resultSet.getString("description"));
						product.setStockQuantity(resultSet.getInt("stock_quantity"));

						productList.add(product);
					}
					return productList;
				}
			}
		}
	}

	private boolean isProductInCart(Connection connection, Customer customer, Product product) throws SQLException {
		String sql = "SELECT * FROM cart WHERE customer_id = ? AND product_id = ?";
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			statement.setInt(1, customer.getCustomerId());
			statement.setInt(2, product.getProductId());

			try (ResultSet resultSet = statement.executeQuery()) {
				return resultSet.next();
			}
		}
	}

}
